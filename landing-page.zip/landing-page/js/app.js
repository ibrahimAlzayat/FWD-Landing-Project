/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Define Global Variables
 *
 */

/**
 * End Global Variables
 * Start Helper Functions
 *
 */

/**
 * End Helper Functions
 * Begin Main Functions
 *
 */

// build the nav

// Add class 'active' to section when near top of viewport

// Scroll to anchor ID using scrollTO event

/**
 * End Main Functions
 * Begin Events
 *
 */

// Build menu




let fragment = document.createDocumentFragment()
const sectionsList = document.querySelectorAll('section')

const navList = document.getElementById('navbar__list')

sectionsList.forEach(section => {
  const navItem = document.createElement('li')
  const navItemLink = document.createElement('a')
  const sectionName = section.getAttribute('data-nav')

  navItemLink.textContent = sectionName
  navItemLink.setAttribute('id', sectionName)
  // Scroll to section on link click
  navItemLink.setAttribute('href', '#' + section.id)
  navItemLink.classList.add('menu__link')

  navItem.appendChild(navItemLink)
  fragment.appendChild(navItem)
})
navList.appendChild(fragment)


window.addEventListener('scroll', () => {
  let fromTop = window.scrollY - 50
  sectionsList.forEach(section => {
    if (
      section.offsetTop > fromTop + 55 &&
      section.offsetTop + section.offsetHeight > fromTop + 55
    ) {
      // Set sections as active
      section.classList.add('your-active-class')
    } else {
      section.classList.remove('your-active-class')
    }
  })
})
